export const TOGGLE_STATUS = 'TOGGLE_STATUS';
export const SORT = 'SORT';
export const REMEMBER_LOGIN = 'REMEMBER_LOGIN';
export const USER = 'USER';
export const SAVEPLAN = 'SAVEPLAN';
export const SAVESPENDTRACKING = 'SAVESPENDTRACKING';
